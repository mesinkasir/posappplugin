const menuList = [
  {
    id: 1,
    name: "Beldos",
    price: 28.05,
    image: "https://1.bp.blogspot.com/-mO6Nlt12ZwY/YAg7dAXqohI/AAAAAAAAMbU/A70dCJlHV0QGE0RJg6IWZqwI2ylc5HksgCLcBGAsYHQ/s225/kemeja%2B3.jpg"
  },
  {
    id: 2,
    name: "Mondis",
    price: 25.05,
    image: "https://1.bp.blogspot.com/-469iS3JH8DA/YAg7eEmZJqI/AAAAAAAAMbY/2oYAGOKEE-UNh4xSqiQ5jHy9u03Xkq_nQCLcBGAsYHQ/s225/kemeja%2B5.jpg"
  },
  {
    id: 3,
    name: "Kosios",
    price: 130.20,
    image: "https://1.bp.blogspot.com/-rWNAPpYI3kM/YAg8BvT1RHI/AAAAAAAAMbw/78LcsPaBFIQOEaHha4O_GAvnKokbDbxCACLcBGAsYHQ/s225/nike.jpg"
  },
  {
    id: 4,
    name: "Manvis",
    price: 1500,
    image: "https://1.bp.blogspot.com/-9e0cuS7pHBA/YAg7dA2KmVI/AAAAAAAAMbQ/_LTUNOAuV6kgZ334zYZPmv1WiMweb_QzQCLcBGAsYHQ/s238/kemeja%2B1.jpg"
  },
  {
    id: 5,
    name: "Ports",
    price: 500,
    image: "https://1.bp.blogspot.com/-uOO4FYVE0aA/YAg8BqvliEI/AAAAAAAAMb0/sEsVF3cT-oUtr82tA5jFSdsX4dIJ6PHVgCLcBGAsYHQ/s238/rocker.jpg"
  },
  {
    id: 6,
    name: "Miguel",
    price: 25.60,
    image: "https://1.bp.blogspot.com/-ZLDMuem_zL0/YAg7dLhc19I/AAAAAAAAMbM/DNoN2YOxZO45eSpeGekLQ9jKc0K_C3hRwCLcBGAsYHQ/s234/kemeja%2B2.jpg"
  },
  {
    id: 7,
    name: "Josk",
    price: 36.80,
    image: "https://1.bp.blogspot.com/-SstVvFz0g1s/YAhC2vR0SHI/AAAAAAAAMdU/2SvEw9VwaHQl3JeBJew_Q9oPsALIYL9GACLcBGAsYHQ/s264/adidas%2Bceltic.jpg"
  },
    {
    id: 8,
    name: "Blues",
    price: 651.20,
    image: "https://1.bp.blogspot.com/-ucFZ3k8E1R4/YAg8firxxfI/AAAAAAAAMcA/4Jl1S-_8HzcupmPk9xYHDeqXXMvv9WgMgCLcBGAsYHQ/s243/captain%2Bamerica.jpg"
  },
      {
    id: 9,
    name: "Divos",
    price: 75.85,
    image: "https://1.bp.blogspot.com/-_klG84lkhCs/YA-69RvK4PI/AAAAAAAAMoI/Rh0IvJWHvPI1lZJ4YIt9u3TkrNOi3y_YQCLcBGAsYHQ/s276/paket1.jpg"
  },
      {
    id: 10,
    name: "Sego",
    price: 85.60,
    image: "https://1.bp.blogspot.com/-LAn6IiLcdPM/YA-69DgVLBI/AAAAAAAAMoE/mDaTj9z9cU4qWW5lemBkVf6JyjPDhHkRwCLcBGAsYHQ/s276/paket2.jpg"
  },
      {
    id: 11,
    name: "Minul",
    price: 850.12,
    image: "https://1.bp.blogspot.com/-EQSuUwAid1w/YA-6_BrftwI/AAAAAAAAMoM/-P-lvB9gua48vOYTQHjgjRmkImiaFE70gCLcBGAsYHQ/s276/paket3.jpg"
  },
      {
    id: 12,
    name: "Monski",
    price: 95.20,
    image: "https://1.bp.blogspot.com/-ANid4eHvXao/YA-6_DB9IOI/AAAAAAAAMoQ/fVTNI_SKGrUcF7i-2YrLajPSpuSUALFNgCLcBGAsYHQ/s276/paket.jpg"
  }
];

const orderList = [];